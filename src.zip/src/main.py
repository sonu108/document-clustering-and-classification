from read_and_clean_documents import *
from text_processing import *
from clustering_functions import *
from plot import *
import pandas as pd
from pprint import pprint
import os 

DATA_FOLDER = "../data/med_connect/"


def get_text_file_list(folder):
    file_name_list = []
    text_string = []
    for file in os.listdir(folder):
        file_name_list.append(file)
        string = ''
        with open(folder + file , encoding = "utf-8") as f:
            for line in f:
                temp = line.strip()
                if temp:
                    string += temp + ' '
        text_string.append(string.strip())
    return file_name_list , text_string


if __name__ == "__main__":
    #Initial read
    import pdb 
    file_name_list , text_string = get_text_file_list(DATA_FOLDER)
    page_list = [page[-11:] for page in file_name_list]
    cleaned_text_string = clean_list(text_string)
    cleaned_text_list = [item.split() for item in cleaned_text_string]

    write_list_to_file('cleaned_content.txt', cleaned_text_list)
    frequent_words_removed_content_as_list = remove_frequent_items(cleaned_text_list, 80)
    write_list_to_file('freq_words_removed_content.txt', frequent_words_removed_content_as_list)

    (frequent_words_removed_content_as_list, frequent_words_removed_content_as_str) = \
       read_from_cleaned_file('freq_words_removed_content.txt')


    (similarity_matrix, tfidf_matrix) = get_similarity_matrix(frequent_words_removed_content_as_str , method = "count")

    kmeams_cost = get_cluster_kmeans_cost(tfidf_matrix)
    line_plot(X = range(1,15) ,Y = kmeams_cost, ,xlabel = "Value of K" ,ylabel = ""  )

    km_clusters,KM= get_cluster_kmeans(tfidf_matrix, 5)  # KMeans


    cluster_dict = {}
    for index,page in enumerate(page_list):
        try:
            cluster_dict[km_clusters[index]].append(page)
        except:
            cluster_dict[km_clusters[index]] = [page]
    pprint(cluster_dict)
    x_pos, y_pos = pca_reduction(similarity_matrix, 10)
    scatter_clusters(x_pos, y_pos, km_clusters, page_list) # Scatter K-means with PCA

    # dbscan_clusters = get_dbscan_cluster(tfidf_matrix, 1.2)
    # dbscan_clusters = dbscan_clusters + 1  # DBScan clusters start from -1
    # x_pos, y_pos = multidim_scaling(similarity_matrix, 2)  # MultidimScaling
    # scatter_clusters(x_pos, y_pos, dbscan_clusters, authors) # Scatter K-means with PCA
    
    # dendogram(similarity_matrix, book_names)
    
    # lda_model = lda_topic_modeling(frequent_words_removed_content_as_list, 5)
    # print(lda_model.print_topics(num_topics=5, num_words=5))
